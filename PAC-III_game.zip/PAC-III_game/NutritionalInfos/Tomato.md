## Cenoura

#### Nome científico: Lucypersicum esculentum

---

###### Informações Nutricionais

Para uma porção de 100g:

- Caloria: 18kcal
- Gordura: 0.2g
- Colesterol: 0mg
- Sódio: 5mg
- Carboidrato: 3.9g
- Proteína: 0.9g
- Cálcio: 10mg
- Ferro: 0.3mg
- Potássio: 237mg
- Cafeína: 0mg
- Vitaminas:
  - A
  - B
  - C
  - K

---

###### Benefícios

Por ser rico em licopeno, o tomate é um potente antioxidante, mantendo a saúde da pele, fortalecendo o sistema imunológico e evitando doenças como infarto e aterosclerose;
Aumenta a saciedade e diminui a fome, facilitando a perda de peso;
Previne o câncer de próstata, doenças cardiovasculares, ajuda a melhorar a visão, a pele e o cabelo, assim como a regular a pressão arterial;
Melhora a saúde dos ossos, previne doenças do fígado e ajuda com a prisão de ventres;
Controla a diabetes, previne anemia e o envelhecimento precoce.

---
