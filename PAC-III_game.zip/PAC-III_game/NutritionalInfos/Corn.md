## Cenoura

#### Nome científico: Zea mays

---

###### Informações Nutricionais

Para uma porção de 100g:

- Caloria: 96kcal
- Gordura: 1.5g
- Colesterol: 0mg
- Sódio: 1mg
- Carboidrato: 21g
- Proteína: 3.4g
- Cálcio: 3mg
- Ferro: 0.5mg
- Potássio: 218mg
- Cafeína: 0mg
- Vitamina:
  - A
  - B1

---

###### Benefícios

Previne doenças nos olhos, fortalece o sistema imunológico e ajuda a emagrecer;
Reduz os níveis de colesterol, ajuda a controlar o açúcar no sangue, dá energia e melhora o trânsito intestinal.

---
