## Cenoura

#### Nome científico: Lactuta sativa

---

###### Informações Nutricionais

Para uma porção de 100g:

- Caloria: 17kcal
- Gordura: 0.3g
- Colesterol: 0mg
- Sódio: 8mg
- Carboidrato: 3.3g
- Proteína: 1.2g
- Cálcio: 33mg
- Ferro: 1mg
- Potássio: 247mg
- Cafeína: 0mg
- Vitaminas:
  - A
  - C

---

###### Benefícios

Melhora a saúde gastrointestinal, regula os níveis de açúcar no sangue, favorece a perda de peso e também ajuda na saúde dos olhos;
Evita o envelhecimento prematuro da pele, dos ossos e previne anemia;
Além disso, ajuda a combater a insônia, possui ação antixodiante, combate prisão de ventre e combate a retenção de líquidos.

---
