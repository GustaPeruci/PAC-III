## Cenoura

#### Nome científico: Fragaria x ananassa

---

###### Informações Nutricionais

Para uma porção de 100g:

- Caloria: 32kcal
- Gordura: 0.3g
- Colesterol: 0mg
- Sódio: 1mg
- Carboidrato: 7.7g
- Proteína: 0.7g
- Cálcio: 16mg
- Ferro: 0.4mg
- Potássio: 153mg
- Cafeína: 0mg
- Vitaminas:
  - A
  - B5
  - B6
  - C
  - E

---

###### Benefícios

Ajuda a diminuir o colesterol, a controlar a pressão arterial e regular o açúcar no sangue;
Melhora a capacidade cognitiva, ajuda a perder peso e a manter a pele firme;
Mantém a saúde dos olhos, melhora o funcionamento do sistema imune e ajuda na prevenção de câncer.

---
