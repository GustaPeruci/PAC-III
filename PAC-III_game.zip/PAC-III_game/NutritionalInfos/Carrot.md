## Cenoura

#### Nome científico: Daucus carota subsp. sativus

---

###### Informações Nutricionais

Para uma porção de 100g:

- Caloria: 35kcal
- Gordura: 0.2g
- Colesterol: 0mg
- Sódio: 58mg
- Carboidrato: 8.2g
- Proteína: 0.8g
- Cálcio: 30mg
- Ferro: 0.3mg
- Potássio: 235mg
- Cafeína: 0mg
- Vitaminas:
  - A
  - B6
  - C
  - K

---

###### Benefícios

Por ser uma comida de baixo teor de glicerídeos, cenouras são particularmente benéficas para diabéticos;
Ajuda a diminuir o nível de açúcar e colesterol no sangue, diminui o risco de doenças e de constipação além de regular os movimentos do intestino;
Ajuda a manter a visão e o sistema imunológico saudáveis;
Melhora a coagulação sanguínea e saúde dos ossos;
Ajuda a controlar a pressão sanguínea;
Também reduz o risco de câncer e ajuda na perda de peso.

---
